function CartPage() {
  return <h1>Savatcha</h1>;
}

export default CartPage;
