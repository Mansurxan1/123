// import React, { useEffect } from "react";
// import { useDispatch, useSelector } from "react-redux";
// import { useParams, useNavigate } from "react-router-dom";
// import { fetchProducts } from "../redux/productSlice";
// import { useTranslation } from "react-i18next";

// const CategoryProducts = () => {
//   const { t } = useTranslation();
//   const { categoryId } = useParams();
//   const navigate = useNavigate();
//   const dispatch = useDispatch();
//   const { categories } = useSelector((state) => state.categories);
//   const { products, loading, error } = useSelector((state) => state.products);

//   useEffect(() => {
//     dispatch(fetchProducts(categoryId));
//   }, [dispatch, categoryId]);

//   if (loading) return <p>{t("loading")}</p>;
//   if (error) return <p>{t("error_loading_products")}</p>;

//   return (
//     <div>
//       <button onClick={() => navigate(-1)}>⬅ {t("back")}</button>
//       <h2>
//         {categories.find((cat) => cat.id === parseInt(categoryId))?.name_uz}
//       </h2>
//       <div>
//         {products.map((product) => (
//           <div key={product.id}>
//             <img
//               src={`${import.meta.env.VITE_API_URL}/${product.photo}`}
//               alt={product.name_uz}
//             />
//             <p>{product.name_uz}</p>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };

// export default CategoryProducts;

import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useParams, useNavigate } from "react-router-dom";
import { fetchProducts } from "../redux/productSlice";
import { useTranslation } from "react-i18next";

const CategoryProducts = () => {
  const { t } = useTranslation();
  const { categoryId } = useParams();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { categories } = useSelector((state) => state.categories);
  const { products, loading, error, status } = useSelector(
    (state) => state.products
  );

  // Faqat bir marta fetch qilish
  useEffect(() => {
    if (status === "idle") {
      dispatch(fetchProducts());
    }
  }, [dispatch, status]);

  if (loading) return <p>{t("loading")}</p>;
  if (error) return <p>{t("error_loading_products")}</p>;

  // Kategoriyaga tegishli mahsulotlarni filtr qilish
  const filteredProducts = products.filter(
    (product) => product.category_id === parseInt(categoryId)
  );

  return (
    <div className="max-w-[450px] mx-auto p-2">
      <button onClick={() => navigate(-1)}>⬅ {t("back")}</button>
      <h2 className="text-xl font-bold my-2">
        {categories.find((cat) => cat.id === parseInt(categoryId))?.name_uz ||
          t("category")}
      </h2>
      <div className="grid grid-cols-2 gap-4">
        {filteredProducts.length > 0 ? (
          filteredProducts.map((product) => (
            <div key={product.id} className="border p-2 rounded-md shadow-md">
              <img
                src={`${import.meta.env.VITE_API_URL}/${product.photo}`}
                alt={product.name_uz}
                className="w-full h-[100px] object-cover rounded-md"
              />
              <p className="text-center mt-2 font-medium">{product.name_uz}</p>
            </div>
          ))
        ) : (
          <p className="text-gray-500">{t("no_products_found")}</p>
        )}
      </div>
    </div>
  );
};

export default CategoryProducts;
