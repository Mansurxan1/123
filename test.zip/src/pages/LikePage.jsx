function LikePage() {
  return <h1>Yoqtirganlar</h1>;
}

export default LikePage;
