import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchCategories } from "../redux/categoriesSlice"; // Redux slice manzilingizni kiriting
import { useTranslation } from "react-i18next";
import { FaAngleDown } from "react-icons/fa6";
import Search from "../components/Search";
import { useNavigate } from "react-router-dom"; // useNavigate importi

const CategoryAll = () => {
  const dispatch = useDispatch();
  const { t } = useTranslation();
  const navigate = useNavigate(); // useNavigate hook'ini chaqirish

  // Redux store-dan kategoriya va loading holatlarini olish
  const { categories, loading, error, status } = useSelector(
    (state) => state.categories
  );

  // selectedBranch Redux store'dan olinadi
  const selectedBranch = useSelector((state) => state.shops.selectedBranch); // Tanlangan filialni olish

  useEffect(() => {
    if (status === "idle") {
      dispatch(fetchCategories()); // Komponent o'rnatilganida kategoriyalarni yuklash
    }
  }, [dispatch, status]);

  // Tanlangan filialga asoslangan kategoriyalarni filtrlash
  const filteredCategories = categories.filter(
    (category) => category.shop_id === selectedBranch?.id // `shop_id`ni tanlangan filialning id bilan solishtirish
  );

  if (loading) return <div>{t("loading")}...</div>;
  if (error)
    return <div className="text-red-500">{t("error_loading_categories")}</div>;

  return (
    <div className="max-w-[450px] mx-auto">
      <Search />
      <div className="flex items-center text-center gap-3 mb-4 rounded-bl-[20px] rounded-br-[20px] border-b-[2px] border-b-[#00000050] px-3 pb-4">
        <button
          onClick={() => navigate(-1)} // Orqaga qaytish uchun navigate(-1) ishlatildi
          className="p-2 bg-white border-[1px] z-10 rounded-lg shadow-[0px_4px_4px_rgba(0,0,0,0.3)]"
        >
          <FaAngleDown className="text-2xl rotate-90" />
        </button>
        <h2 className="text-2xl w-full mx-auto font-semibold max-w-[300px]">
          {t("all_categories")}
        </h2>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-2 gap-4 p-4 ">
        {filteredCategories.length > 0 ? (
          filteredCategories.map((category) => (
            <div key={category.id} className="border rounded-md shadow-lg">
              <img
                src={`${import.meta.env.VITE_API_URL}/${category.photo}`} // Rasm URL
                alt={category.name_uz}
                className="w-full h-[130px] object-cover rounded-md mb-2"
              />
              <h3 className="text-xl text-center pb-1 font-semibold">
                {category.name_uz}
              </h3>
            </div>
          ))
        ) : (
          <p className="text-center text-gray-500">
            {t("no_categories_found")}
          </p>
        )}
      </div>
    </div>
  );
};

export default CategoryAll;
