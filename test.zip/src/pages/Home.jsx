import React from "react";
import Search from "../components/Search";
import Banner from "../components/Banner";
import Categories from "../components/Categories";
import Product from "../components/Product";

const Home = () => {
  return (
    <>
      <Search />
      <Banner />
      <Categories />
      <Product />
    </>
  );
};

export default Home;
