import React, { useEffect } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/free-mode";
import { FreeMode } from "swiper/modules";
import { useTranslation } from "react-i18next";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { fetchCategories } from "../redux/categoriesSlice";

const Categories = () => {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const dispatch = useDispatch();

  const { categories, loading, error, status } = useSelector(
    (state) => state.categories
  );

  const selectedBranch = useSelector((state) => state.shops.selectedBranch); // Tanlangan filialni olish
  // faqat bir marta fetch qilish
  useEffect(() => {
    if (status === "idle") {
      dispatch(fetchCategories());
    }
  }, [dispatch, status]);

  if (loading) {
    return <p>Loading...</p>; // Yuklanayotganda ko'rsatiladigan matn
  }

  if (error) {
    return <p className="text-red-500">{t("error_loading_categories")}</p>;
  }

  // Tanlangan filialga tegishli kategoriyalarni filtrlash
  const filteredCategories = categories.filter(
    (cat) => cat.shop_id === selectedBranch?.id
  );

  return (
    <div className="max-w-[450px] mx-auto p-2">
      <div className="flex justify-between items-center mb-2">
        <h2 className="text-xl font-bold">{t("category")}</h2>
        <Link to="/category-all" className="text-sm text-gray-600 border-b-2">
          {t("all_categories")}
        </Link>
      </div>

      {filteredCategories.length > 0 ? (
        <Swiper
          slidesPerView={4.2}
          spaceBetween={8}
          freeMode={true}
          modules={[FreeMode]}
          breakpoints={{
            320: { slidesPerView: 2.8, spaceBetween: 6 },
            350: { slidesPerView: 3.2, spaceBetween: 6 },
            400: { slidesPerView: 3.7, spaceBetween: 6 },
            440: { slidesPerView: 4.2, spaceBetween: 8 },
          }}
        >
          {filteredCategories.map((cat) => (
            <SwiperSlide key={cat.id}>
              <div
                className="w-[100px] cursor-pointer flex flex-col items-center text-center"
                onClick={() => navigate(`/category/${cat.id}`)}
              >
                <img
                  src={`${import.meta.env.VITE_API_URL}/${cat.photo}`}
                  alt={cat.name_uz}
                  className="w-full h-[80px] rounded-md border object-cover shadow-md"
                />
                <p className="text-xs mt-1 font-medium">{cat.name_uz}</p>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      ) : (
        <p className="text-center text-gray-500">{t("no_categories_found")}</p>
      )}
    </div>
  );
};

export default Categories;
