import React, { useEffect } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/free-mode";
import { FreeMode } from "swiper/modules";
import { useDispatch, useSelector } from "react-redux";
import { fetchProducts } from "../redux/productSlice";
import { fetchCategories } from "../redux/categoriesSlice";
import { useTranslation } from "react-i18next";

const Product = () => {
  const { t } = useTranslation();
  const dispatch = useDispatch();

  const { products, status, error } = useSelector((state) => state.products);
  const { categories } = useSelector((state) => state.categories);
  const selectedBranch = useSelector((state) => state.shops.selectedBranch);

  useEffect(() => {
    dispatch(fetchProducts());
    dispatch(fetchCategories());
  }, [dispatch]);

  // 🔹 Tanlangan branchga tegishli mahsulotlarni filtr qilish
  const filteredProducts = products.filter(
    (product) => product.shop_id === selectedBranch?.id
  );

  // 🔹 Kategoriyalar bo‘yicha mahsulotlarni guruhlash
  const groupedByCategory = filteredProducts.reduce((acc, product) => {
    const category = categories.find((cat) => cat.id === product.category_id);
    const categoryName = category ? category.name_uz : "Noma'lum";

    if (!acc[categoryName]) {
      acc[categoryName] = {
        name: categoryName,
        products: [],
      };
    }

    acc[categoryName].products.push(product);
    return acc;
  }, {});

  // 🔹 Narxni formatlash
  const formatPrice = (price) =>
    `${Number.parseInt(price).toLocaleString()} ${t("UZS")}`;

  // 🔹 Yuklanish holati
  if (status === "loading")
    return <div className="text-center text-lg">{t("loading")}</div>;
  if (status === "failed")
    return (
      <div className="text-center text-lg text-red-500">
        {t("error_loading_products")}
      </div>
    );
  if (filteredProducts.length === 0)
    return <div className="text-center text-lg">{t("no_products_found")}</div>;

  return (
    <div className="max-w-[450px] mx-auto p-2">
      {Object.values(groupedByCategory).map(({ name, products }) => (
        <div key={name} className="mb-8">
          <h2 className="text-lg font-semibold capitalize mb-2">{name}</h2>

          <Swiper
            slidesPerView={4.2}
            spaceBetween={8}
            freeMode={true}
            modules={[FreeMode]}
            breakpoints={{
              320: { slidesPerView: 1.9, spaceBetween: 6 },
              350: { slidesPerView: 2.2, spaceBetween: 6 },
              400: { slidesPerView: 2.3, spaceBetween: 6 },
              440: { slidesPerView: 2.5, spaceBetween: 8 },
            }}
          >
            {products.map((product) => (
              <SwiperSlide key={product.id}>
                <div className=" cursor-pointer mr-3 flex flex-col items-center text-center">
                  <img
                    src={`${import.meta.env.VITE_API_URL}/${product.photo}`}
                    alt={product.name_uz}
                    className="w-full h-[120px] rounded-md border object-cover shadow-md"
                  />
                  <p className="text-xs mt-1 font-medium">{product.name_uz}</p>
                  <p className="text-sm text-gray-500">
                    {formatPrice(product.price)}
                  </p>
                </div>
              </SwiperSlide>
            ))}
          </Swiper>
        </div>
      ))}
    </div>
  );
};

export default Product;
